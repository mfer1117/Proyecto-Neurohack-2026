---
name: PWA development cache
description: Prevent stale service-worker modules from interfering with Vite preview sessions.
---

Do not keep the Bluba PWA service worker active during Vite development. In
development, unregister any existing Bluba service worker and delete its caches;
only register the worker in production.

**Why:** A cache-first worker can serve old JavaScript modules alongside a fresh
Vite bundle, which can surface misleading React hook-dispatcher failures such
as a null `useRef`.

**How to apply:** Preserve the development cleanup and production-only worker
registration when changing PWA or entry-point behavior. Bump and clean the
production cache name when changing cached shell assets.
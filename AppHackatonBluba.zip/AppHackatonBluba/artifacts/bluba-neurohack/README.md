# Bluba NeuroHack

Prototipo PWA mobile-first para NeuroHack 2026. Bluba reúne observaciones de
familia, escuela y equipo de salud para visualizar patrones individuales y
mostrar una estimación demostrativa de riesgo de desregulación en las próximas
24 horas. No es una herramienta diagnóstica ni reemplaza evaluación
profesional.

## Ejecutar

Desde la raíz del proyecto:

```bash
pnpm --filter @workspace/bluba-neurohack run dev
```

La aplicación está preparada para ejecutarse en Replit con el workflow web
configurado. También puede instalarse en la pantalla de inicio desde un
navegador compatible gracias al `public/manifest.json` y `public/sw.js`.

## Fuente de datos

El prototipo usa `src/data/dataset_modelo_24h.csv`, una copia de
`datos/dataset_modelo_24h.csv`, como fuente de verdad para el estado diario,
relacionando siempre `id_caso` + `fecha_indice`.

- El dashboard usa la última fecha disponible y una ventana de siete días.
- El historial usa las filas del caso seleccionado.
- `puntaje_riesgo_sintetico` no se muestra ni se usa en el cálculo.
- `crisis_proximas_24h` se conserva únicamente como resultado histórico dentro
  del diario de vida; no participa de la estimación.

## Servicio de predicción

La UI no calcula el riesgo directamente. Dashboard, explicación y escenarios
consumen el contrato común de `src/services/predictionService.ts`.

- **Modo `mock` (predeterminado):** calcula una señal local y demostrativa desde
  las variables observables del CSV y los registros locales.
- **Modo `api`:** mantiene el mismo contrato visual, pero envía el contexto a
  `POST {VITE_PREDICTION_API_URL}/predict`. Si el endpoint no está configurado,
  la interfaz mantiene el último resultado y comunica el error.

El modo se puede alternar desde **Perfil → Motor de predicción** y queda
guardado localmente. Así, al conectar el servicio Python solo será necesario
definir `VITE_PREDICTION_API_URL`; no hace falta cambiar los componentes
visuales.

## Dónde modificar la demo

La implementación funcional está centralizada en `src/App.tsx` para facilitar
la presentación y el prototipado:

- **Datos mock:** busca `PATIENTS`, `INITIAL_HISTORY` y `STRATEGIES`.
- **Reglas de riesgo:** `calculateRisk` separa `riskScore` de
  `confidenceScore`; ajusta sus factores sin convertir datos faltantes en
  menor riesgo.
- **Explicaciones:** `explainRisk` genera las razones visibles en lenguaje
  natural.
- **Escenarios:** `getScenarios` deriva posibilidades del perfil y del
  historial, sin presentarlas como certezas.
- **Priorización de estrategias:** `getPrioritizedStrategies` ordena el banco
  personal por efectividad histórica.
- **Registros persistentes:** los nuevos registros, el rol y el paciente activo
  se guardan en `localStorage` bajo la clave `bluba-neurohack-state`.

Los datos usados en esta versión son ficticios y anonimizados. No se solicitan
nombre completo, RUT, dirección, geolocalización, cámara ni micrófono.
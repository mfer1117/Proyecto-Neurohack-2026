import datasetCsv from "./dataset_modelo_24h.csv?raw";

export type DatasetRow = {
  id_caso: string;
  fecha_indice: string;
  perfil_sensorial_predominante: string;
  rango_edad: string;
  calidad_sueno: string;
  modo_despertar: string;
  adherencia_medicacion: string;
  estado_gastrointestinal: string;
  nivel_regulacion_general_dia: string;
  asistencia_establecimiento: string;
  cambio_rutina_escolar: string;
  carga_demanda_academica: string;
  nivel_ruido_ambiente: string;
  transicion_dificil: string;
  hubo_sesion_profesional: string;
  nivel_alerta_inicial_sesion: string;
  nivel_alerta_final_sesion: string;
  eventos_mismo_dia: string;
  crisis_proximas_24h: string;
  [key: string]: string;
};

function parseDataset(csv: string): DatasetRow[] {
  const lines = csv.replace(/^\uFEFF/, "").trim().split(/\r?\n/);
  const headers = lines.shift()?.split(";") ?? [];

  return lines
    .filter(Boolean)
    .map((line) => {
      const values = line.split(";");
      return headers.reduce((row, header, index) => {
        row[header] = values[index]?.trim() ?? "";
        return row;
      }, {} as DatasetRow);
    });
}

export const datasetRows = parseDataset(datasetCsv);
export const datasetCaseIds = [...new Set(datasetRows.map((row) => row.id_caso))];
export const datasetLatestDate = datasetRows.reduce(
  (latest, row) => (row.fecha_indice > latest ? row.fecha_indice : latest),
  "",
);

export function rowsForCase(idCaso: string) {
  return datasetRows
    .filter((row) => row.id_caso === idCaso)
    .sort((a, b) => a.fecha_indice.localeCompare(b.fecha_indice));
}

export function rowForDate(idCaso: string, fechaIndice = datasetLatestDate) {
  return rowsForCase(idCaso).find((row) => row.fecha_indice === fechaIndice);
}

export function recentRows(
  idCaso: string,
  fechaIndice = datasetLatestDate,
  days = 7,
) {
  return rowsForCase(idCaso)
    .filter((row) => row.fecha_indice <= fechaIndice)
    .slice(-days);
}
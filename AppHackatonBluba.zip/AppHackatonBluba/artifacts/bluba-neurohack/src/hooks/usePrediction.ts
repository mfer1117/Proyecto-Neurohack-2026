import { useEffect, useMemo, useState } from "react";
import {
  predict,
  predictMock,
  type PredictionMode,
  type PredictionRecordStore,
  type PredictionResult,
} from "@/services/predictionService";

export function usePrediction(patientId: string, records: PredictionRecordStore, mode: PredictionMode) {
  const input = useMemo(() => ({ patientId, records }), [patientId, records]);
  const mockResult = useMemo(() => predictMock(input), [input]);
  const [result, setResult] = useState<PredictionResult>(mockResult);
  const [isLoading, setIsLoading] = useState(mode === "api");
  const [error, setError] = useState("");
  const [isStaleMock, setIsStaleMock] = useState(mode === "api");

  useEffect(() => {
    let current = true;
    setError("");
    if (mode === "mock") {
      setResult(mockResult);
      setIsLoading(false);
      setIsStaleMock(false);
      return () => { current = false; };
    }
    setIsLoading(true);
    setIsStaleMock(true);
    predict(input, mode)
      .then((next) => {
        if (!current) return;
        setResult(next);
        setIsLoading(false);
        setIsStaleMock(false);
      })
      .catch((reason: unknown) => {
        if (!current) return;
        setError(reason instanceof Error ? reason.message : "No fue posible obtener la estimación.");
        setIsLoading(false);
        setIsStaleMock(true);
      });
    return () => { current = false; };
  }, [input, mockResult, mode]);

  return { ...result, isLoading, error, isStaleMock };
}
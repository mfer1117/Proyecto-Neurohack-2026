import type { DatasetRow } from "@/data/dataset";
import type { PredictionRecordStore } from "@/services/predictionService";

export const achievementCategories = [
  "Autorregulación",
  "Comunicación",
  "Transiciones",
  "Participación",
  "Autonomía",
  "Uso de estrategias",
  "Interacción social",
  "Metas terapéuticas",
] as const;

export type AchievementCategory = (typeof achievementCategories)[number];

export const achievementIcons = ["🏅", "⭐", "🌱", "💬", "🧭", "🤝", "✨", "🎯"] as const;
export type AchievementIcon = (typeof achievementIcons)[number];

export type Achievement = {
  id: string;
  title: string;
  category: AchievementCategory;
  date: string;
  description: string;
  icon: AchievementIcon;
  points?: number;
  source: "automatic" | "manual";
};

export type AchievementStore = Record<string, Achievement[]>;

export type AchievementSummary = {
  achievements: Achievement[];
  latest: Achievement | null;
  totalPoints: number;
  badges: string[];
  currentStreak: number;
  nextMilestone: { label: string; target: number; progress: number } | null;
  milestones: { label: string; target: number; reached: boolean }[];
};

type AchievementInput = {
  patientId: string;
  rows: DatasetRow[];
  records: PredictionRecordStore;
  manual: Achievement[];
};

const milestones = [
  { label: "Primer paso compartido", target: 20 },
  { label: "Estrategias en movimiento", target: 50 },
  { label: "Una red que aprende", target: 100 },
];

function stableRow(row: DatasetRow) {
  return row.nivel_regulacion_general_dia === "Excelente" ||
    row.nivel_regulacion_general_dia === "Estable con Apoyo";
}

function dayDifference(older: string, newer: string) {
  const start = Date.parse(`${older}T00:00:00Z`);
  const end = Date.parse(`${newer}T00:00:00Z`);
  return Math.round((end - start) / 86_400_000);
}

function observedRows({ patientId, rows, records }: Omit<AchievementInput, "manual">) {
  const byDate = new Map<string, DatasetRow>();
  rows.forEach((row) => byDate.set(row.fecha_indice, { ...row }));
  const rowFor = (date: string) => byDate.get(date) || ({ id_caso: patientId, fecha_indice: date } as DatasetRow);

  records.daily.filter((record) => record.id_caso === patientId && record.fecha).forEach((record) => {
    const row = rowFor(record.fecha);
    byDate.set(record.fecha, { ...row, nivel_regulacion_general_dia: record.nivel_regulacion_general_dia || row.nivel_regulacion_general_dia });
  });
  records.school.filter((record) => record.id_caso === patientId && record.fecha).forEach((record) => {
    const row = rowFor(record.fecha);
    byDate.set(record.fecha, {
      ...row,
      cambio_rutina_escolar: record.cambios_de_rutina || row.cambio_rutina_escolar,
      transicion_dificil: record.transicion_problemática || row.transicion_dificil,
    });
  });

  return [...byDate.values()].sort((a, b) => a.fecha_indice.localeCompare(b.fecha_indice));
}

function automaticAchievements({ patientId, rows, records }: Omit<AchievementInput, "manual">): Achievement[] {
  const sortedRows = rows.slice().sort((a, b) => a.fecha_indice.localeCompare(b.fecha_indice));
  const generated: Achievement[] = [];

  let stableRun: DatasetRow[] = [];
  const completedRuns: DatasetRow[][] = [];
  for (const row of sortedRows) {
    if (stableRow(row) && (!stableRun.length || dayDifference(stableRun.at(-1)!.fecha_indice, row.fecha_indice) === 1)) {
      stableRun = [...stableRun, row];
    } else {
      if (stableRun.length >= 3) completedRuns.push(stableRun);
      stableRun = stableRow(row) ? [row] : [];
    }
  }
  if (stableRun.length >= 3) completedRuns.push(stableRun);
  completedRuns.forEach((run) => {
    const date = run[2].fecha_indice;
    generated.push({
      id: `automatic-regulation-${patientId}-${date}`,
      title: "Completó 3 días con regulación estable.",
      category: "Autorregulación",
      date,
      description: "Sostuvo señales de regulación y pudo apoyarse en lo que ya conoce.",
      icon: "🏅",
      points: 20,
      source: "automatic",
    });
  });

  const transitionRow = sortedRows.findLast((row) => row.transicion_dificil === "No" && row.cambio_rutina_escolar === "Sí");
  if (transitionRow) {
    generated.push({
      id: `automatic-transition-${patientId}-${transitionRow.fecha_indice}`,
      title: "Realizó una transición con cambio de rutina.",
      category: "Transiciones",
      date: transitionRow.fecha_indice,
      description: "Pudo atravesar un cambio del entorno sin que la transición fuera difícil.",
      icon: "🧭",
      points: 15,
      source: "automatic",
    });
  }

  const eventRecords = records.events.filter((record) => record.id_caso === patientId);
  const strategyEvent = eventRecords.find((record) =>
    Boolean(record.estrategia_calma_aplicada?.trim()) &&
    ["Efectiva", "Parcial"].includes(record.resultado_estrategia || ""),
  );
  if (strategyEvent) {
    generated.push({
      id: `automatic-strategy-${patientId}`,
      title: "Usó una estrategia previamente aprendida.",
      category: "Uso de estrategias",
      date: (strategyEvent.fecha_hora || "").slice(0, 10) || sortedRows.at(-1)?.fecha_indice || "",
      description: "Puso en práctica un apoyo conocido y registró cómo le ayudó.",
      icon: "🌱",
      points: 20,
      source: "automatic",
    });
  }

  const signalEvent = eventRecords.find((record) => record.tipo_evento === "Señal temprana" && record.detonante_gatillante?.trim());
  if (signalEvent) {
    generated.push({
      id: `automatic-signal-${patientId}`,
      title: "Identificó una señal antes de desregularse.",
      category: "Comunicación",
      date: (signalEvent.fecha_hora || "").slice(0, 10) || sortedRows.at(-1)?.fecha_indice || "",
      description: `Pudo nombrar un contexto que necesitaba apoyo: ${signalEvent.detonante_gatillante}.`,
      icon: "💬",
      points: 15,
      source: "automatic",
    });
  }

  const usedStrategies = Object.values(records.strategyUsesByPatient?.[patientId] || {}).reduce((sum, count) => sum + count, 0);
  if (usedStrategies > 0 && !strategyEvent) {
    generated.push({
      id: `automatic-choice-${patientId}`,
      title: "Volvió a elegir una estrategia conocida.",
      category: "Autonomía",
      date: sortedRows.at(-1)?.fecha_indice || "",
      description: "Registrar una estrategia también muestra iniciativa para cuidar el propio bienestar.",
      icon: "🧭",
      points: 10,
      source: "automatic",
    });
  }

  return generated;
}

function currentStreak(rows: DatasetRow[]) {
  const sortedRows = rows.slice().sort((a, b) => a.fecha_indice.localeCompare(b.fecha_indice));
  let streak = 0;
  for (let index = sortedRows.length - 1; index >= 0; index -= 1) {
    const row = sortedRows[index];
    const activeProgress = stableRow(row) || row.transicion_dificil === "No";
    if (!activeProgress) break;
    if (index < sortedRows.length - 1 && dayDifference(row.fecha_indice, sortedRows[index + 1].fecha_indice) !== 1) break;
    streak += 1;
  }
  return streak;
}

export function getAchievementSummary(input: AchievementInput): AchievementSummary {
  const normalizedRows = observedRows(input);
  const automatic = automaticAchievements({ ...input, rows: normalizedRows });
  const byId = new Map<string, Achievement>();
  [...automatic, ...input.manual].forEach((achievement) => byId.set(achievement.id, achievement));
  const achievements = [...byId.values()].filter((achievement) => achievement.date).sort((a, b) => {
    const dateOrder = b.date.localeCompare(a.date);
    return dateOrder || b.id.localeCompare(a.id);
  });
  const totalPoints = achievements.reduce((sum, achievement) => sum + (achievement.points || 0), 0);
  const reachedMilestones = milestones.map((milestone) => ({
    ...milestone,
    reached: totalPoints >= milestone.target,
  }));
  const next = milestones.find((milestone) => totalPoints < milestone.target);

  return {
    achievements,
    latest: achievements[0] || null,
    totalPoints,
    badges: [...new Set(achievements.map((achievement) => achievement.icon))],
    currentStreak: currentStreak(normalizedRows),
    nextMilestone: next ? {
      ...next,
      progress: Math.min(100, Math.round((totalPoints / next.target) * 100)),
    } : null,
    milestones: reachedMilestones,
  };
}

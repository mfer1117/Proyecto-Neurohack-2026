import {
  datasetLatestDate,
  recentRows,
  rowForDate,
  rowsForCase,
  type DatasetRow,
} from "@/data/dataset";

export type PredictionMode = "mock" | "api";

export type PredictionRecord = Record<string, string>;
export type PredictionRecordStore = {
  daily: PredictionRecord[];
  events: PredictionRecord[];
  professional: PredictionRecord[];
  school: PredictionRecord[];
  goals: PredictionRecord[];
  strategyUses: Record<string, number>;
  strategyUsesByPatient: Record<string, Record<string, number>>;
};

export type PredictionInput = {
  patientId: string;
  fechaIndice?: string;
  records: PredictionRecordStore;
};

export type PredictionFactor = {
  label: string;
  value: number;
  direction: "up" | "down" | "neutral";
};

export type PredictionScenario = {
  title: string;
  signs: string;
  level: string;
  preventiveStrategy: string;
  regulationStrategy: string;
  color: string;
};

export type PredictionResult = {
  riskScore: number;
  confidenceScore: number;
  current: DatasetRow;
  recent: DatasetRow[];
  trendScores: number[];
  factors: PredictionFactor[];
  reasons: string[];
  scenarios: PredictionScenario[];
  source: "mock" | "api";
};

const MODE_STORAGE_KEY = "bluba-neurohack-prediction-mode";

export function getPredictionMode(): PredictionMode {
  if (typeof window === "undefined") return "mock";
  return window.localStorage.getItem(MODE_STORAGE_KEY) === "api" ? "api" : "mock";
}

export function setPredictionMode(mode: PredictionMode) {
  window.localStorage.setItem(MODE_STORAGE_KEY, mode);
}

function scoreObservableRow(row: Partial<DatasetRow>, recent: DatasetRow[] = []) {
  let score = 18;
  if (row.calidad_sueno === "Interrumpido") score += 22;
  if (row.calidad_sueno === "Dificultad de Conciliación") score += 18;
  if (row.modo_despertar === "Irritable/Llorando") score += 20;
  if (row.modo_despertar === "Cansado/Con Sueño") score += 9;
  if (row.estado_gastrointestinal === "Estreñimiento") score += 9;
  if (row.estado_gastrointestinal === "Diarrea") score += 13;
  if (row.nivel_regulacion_general_dia === "Desregulación Frecuente") score += 25;
  if (row.nivel_regulacion_general_dia === "Estable con Apoyo") score += 8;
  if (row.nivel_regulacion_general_dia === "Excelente") score -= 5;
  if (row.cambio_rutina_escolar === "Sí") score += 13;
  if (row.carga_demanda_academica === "Alta") score += 9;
  if (row.carga_demanda_academica === "Moderada") score += 4;
  if (row.nivel_ruido_ambiente === "Alto") score += 14;
  if (row.nivel_ruido_ambiente === "Moderado") score += 6;
  if (row.transicion_dificil === "Sí") score += 14;
  if (row.estado_alerta === "Muy alerta" || row.nivel_alerta_inicial_sesion === "Alto (Sobreexcitado)") score += 8;
  if (row.eventos_mismo_dia === "1") score += 17;
  if (recent.filter((item) => item.calidad_sueno !== "Reparador").length >= 2) score += 12;
  if (recent.filter((item) => item.nivel_regulacion_general_dia === "Desregulación Frecuente").length >= 2) score += 10;
  if (row.nivel_regulacion_general_dia === "Excelente" && row.calidad_sueno === "Reparador") score -= 8;
  return Math.max(4, Math.min(96, score));
}

function observedRowFor(input: PredictionInput): DatasetRow {
  const source = rowForDate(input.patientId, input.fechaIndice) ??
    rowsForCase(input.patientId)[0] ??
    ({} as DatasetRow);
  const daily = input.records.daily.filter((item) => item.id_caso === input.patientId).at(-1);
  const school = input.records.school.filter((item) => item.id_caso === input.patientId).at(-1);
  const event = input.records.events.filter((item) => item.id_caso === input.patientId).at(-1);
  const professional = input.records.professional.filter((item) => item.id_caso === input.patientId).at(-1);
  return {
    ...source,
    ...(daily ? {
      calidad_sueno: daily.calidad_sueno,
      modo_despertar: daily.modo_despertar,
      adherencia_medicacion: daily.adherencia_medicacion,
      estado_gastrointestinal: daily.estado_gastrointestinal,
      nivel_regulacion_general_dia: daily.nivel_regulacion_general_dia,
    } : {}),
    ...(school ? {
      asistencia_establecimiento: school.asistencia_jornada,
      cambio_rutina_escolar: school.cambios_de_rutina,
      nivel_ruido_ambiente: school.ruido_sobrecarga_ambiental,
      transicion_dificil: school.transicion_problemática,
      estado_alerta: school.estado_alerta,
    } : {}),
    ...(event ? { eventos_mismo_dia: "1" } : {}),
    ...(professional ? {
      hubo_sesion_profesional: "Sí",
      nivel_alerta_inicial_sesion: professional.nivel_alerta_inicial,
      nivel_alerta_final_sesion: professional.nivel_alerta_final,
    } : {}),
  } as DatasetRow;
}

function explainRisk(current: DatasetRow, recent: DatasetRow[]) {
  const reasons: string[] = [];
  const alteredSleepDays = recent.filter((row) => row.calidad_sueno !== "Reparador").length;
  const difficultTransitions = recent.filter((row) => row.transicion_dificil === "Sí").length;
  const sameDayEvents = recent.filter((row) => row.eventos_mismo_dia === "1").length;
  if (alteredSleepDays) reasons.push(`Durante los últimos ${recent.length} días hubo ${alteredSleepDays} registro(s) con sueño no reparador.`);
  if (current.modo_despertar === "Irritable/Llorando") reasons.push("El despertar irritable aparece como una señal relevante para organizar los apoyos de hoy.");
  if (current.estado_gastrointestinal !== "Normal") reasons.push(`El estado gastrointestinal registrado es ${current.estado_gastrointestinal.toLowerCase()}, una condición que puede reducir el margen de regulación.`);
  if (current.cambio_rutina_escolar === "Sí" || current.transicion_dificil === "Sí") reasons.push("El contexto escolar registra cambios o una transición difícil que conviene anticipar.");
  if (current.nivel_ruido_ambiente === "Alto" || current.estado_alerta === "Muy alerta") reasons.push("La sobrecarga ambiental o el estado de alerta elevado están presentes en la observación más reciente.");
  if (sameDayEvents) reasons.push(`El historial contiene ${sameDayEvents} día(s) reciente(s) con eventos registrados.`);
  if (difficultTransitions > 1) reasons.push(`Las transiciones difíciles aparecen en ${difficultTransitions} de los últimos ${recent.length} días.`);
  if (current.nivel_regulacion_general_dia === "Excelente" && current.calidad_sueno === "Reparador") reasons.push("El último registro combina sueño reparador y regulación excelente.");
  if (!reasons.length) reasons.push(
    "La señal se mantiene dentro del rango observado en el historial individual.",
    "La información reciente aún está construyendo el contexto del día.",
    "Completar registros de familia, escuela o profesional puede mejorar la lectura.",
  );
  return reasons.slice(0, 3);
}

function buildScenarios(current: DatasetRow, history: DatasetRow[], riskScore: number): PredictionScenario[] {
  const sensory = current.perfil_sensorial_predominante ?? "";
  const candidates = [
    {
      title: "Sobrecarga Sensorial",
      matches: history.filter((row) => row.nivel_ruido_ambiente === "Alto" || row.perfil_sensorial_predominante?.includes("Auditivo")).length,
      signs: "• cubrirse los oídos o buscar distancia\n• irritabilidad ante el ruido\n• aumento de inquietud\n• búsqueda de aislamiento",
      preventiveStrategy: "Reducir estímulos ambientales y anticipar una pausa sensorial.",
      regulationStrategy: "Trasladar a un espacio de menor estimulación y aplicar una estrategia previamente efectiva.",
      color: "bg-[hsl(var(--chart-5)/.11)] text-[hsl(var(--chart-5))]",
    },
    {
      title: "Transición de Actividad",
      matches: history.filter((row) => row.transicion_dificil === "Sí" || row.cambio_rutina_escolar === "Sí").length,
      signs: "• resistencia al cambio\n• frustración o aumento de tensión\n• dificultad para abandonar una actividad\n• inquietud al cambiar de contexto",
      preventiveStrategy: "Anticipar el cambio mediante apoyo visual o temporizador.",
      regulationStrategy: "Reducir demandas, ofrecer una pausa breve y retomar la transición gradualmente.",
      color: "bg-[hsl(var(--chart-4)/.15)] text-[hsl(32_70%_35%)]",
    },
    {
      title: "Alimentación",
      matches: history.filter((row) => row.estado_gastrointestinal && row.estado_gastrointestinal !== "Normal").length,
      signs: "• menor disponibilidad para participar\n• necesidad de una pausa durante la alimentación\n• irritabilidad o incomodidad corporal\n• rechazo de demandas en ese momento",
      preventiveStrategy: "Cuidar el contexto de alimentación y ofrecer opciones conocidas sin forzar.",
      regulationStrategy: "Dar tiempo, bajar la carga de demandas y acompañar el malestar sin apresurar la recuperación.",
      color: "bg-[hsl(var(--chart-3)/.12)] text-[hsl(var(--chart-3))]",
    },
    {
      title: "Desregulación Emocional",
      matches: history.filter((row) => row.modo_despertar === "Irritable/Llorando" || row.nivel_regulacion_general_dia === "Desregulación Frecuente" || row.nivel_alerta_inicial_sesion === "Alto (Sobreexcitado)").length,
      signs: "• llanto o irritabilidad\n• rechazo de demandas\n• dificultad para comunicar necesidad de ayuda\n• aumento de tensión emocional",
      preventiveStrategy: "Disminuir la carga de demandas y ofrecer una estrategia conocida de autorregulación.",
      regulationStrategy: "Usar acompañamiento con baja carga verbal y facilitar una estrategia de calma previamente efectiva.",
      color: "bg-[hsl(var(--chart-2)/.12)] text-[hsl(var(--primary))]",
    },
  ];
  const profileFallback = sensory.includes("Auditivo") || current.nivel_ruido_ambiente === "Alto"
    ? "Sobrecarga Sensorial"
    : current.transicion_dificil === "Sí" || current.cambio_rutina_escolar === "Sí"
      ? "Transición de Actividad"
      : "Desregulación Emocional";
  const prioritized = candidates
    .sort((a, b) => b.matches - a.matches)
    .filter((candidate) => candidate.matches > 0);
  const fallback = candidates.find((candidate) => candidate.title === profileFallback) || candidates[0];
  const selected = (prioritized.length ? prioritized : [fallback, ...candidates.filter((candidate) => candidate.title !== fallback.title)])
    .slice(0, riskScore >= 45 ? 3 : 2);
  return selected.map((scenario, index) => ({
    title: scenario.title,
    signs: scenario.signs,
    level: index === 0 && riskScore >= 70 ? "Relativo alto" : index === 0 ? "Relativo medio" : index === 1 ? "Relativo medio" : "Relativo bajo",
    preventiveStrategy: scenario.preventiveStrategy,
    regulationStrategy: scenario.regulationStrategy,
    color: scenario.color,
  }));
}

function buildPrediction(input: PredictionInput): PredictionResult {
  const fechaIndice = input.fechaIndice ?? datasetLatestDate;
  const recent = recentRows(input.patientId, fechaIndice, 7);
  const history = rowsForCase(input.patientId);
  const current = observedRowFor({ ...input, fechaIndice });
  const riskScore = scoreObservableRow(current, recent);
  const signals = [
    current.calidad_sueno,
    current.modo_despertar,
    current.estado_gastrointestinal,
    current.nivel_regulacion_general_dia,
    current.asistencia_establecimiento,
    current.cambio_rutina_escolar,
    current.nivel_ruido_ambiente,
    current.transicion_dificil,
    current.hubo_sesion_profesional,
  ];
  const missing = signals.filter((value) => !value || value === "Sin sesión" || value === "No aplica (fin de semana)").length;
  const recentCoverage = Math.min(18, Math.round((recent.length / 7) * 18));
  const confidenceScore = Math.max(28, Math.min(94, 78 - missing * 5 + recentCoverage + Math.min(8, input.records.daily.length + input.records.school.length)));
  const alteredSleep = recent.filter((row) => row.calidad_sueno !== "Reparador").length;
  const factors: PredictionFactor[] = [
    { label: current.calidad_sueno === "Reparador" ? "Sueño reparador" : `Sueño ${current.calidad_sueno.toLowerCase()}`, value: Math.min(92, 18 + alteredSleep * 18 + (current.calidad_sueno === "Reparador" ? 0 : 20)), direction: current.calidad_sueno === "Reparador" ? "down" : "up" },
    { label: current.transicion_dificil === "Sí" ? "Transición difícil" : current.cambio_rutina_escolar === "Sí" ? "Cambio de rutina" : `Ruido ${current.nivel_ruido_ambiente.toLowerCase()}`, value: current.transicion_dificil === "Sí" ? 76 : current.cambio_rutina_escolar === "Sí" ? 66 : current.nivel_ruido_ambiente === "Alto" ? 58 : 24, direction: current.transicion_dificil === "Sí" || current.cambio_rutina_escolar === "Sí" ? "up" : "neutral" },
    { label: current.nivel_regulacion_general_dia, value: current.nivel_regulacion_general_dia === "Desregulación Frecuente" ? 82 : current.estado_gastrointestinal !== "Normal" ? 64 : current.eventos_mismo_dia === "1" ? 61 : 26, direction: current.nivel_regulacion_general_dia === "Excelente" ? "down" : "up" },
  ];
  return {
    riskScore,
    confidenceScore,
    current,
    recent,
    trendScores: recent.map((row, index) => scoreObservableRow(row, recent.slice(Math.max(0, index - 2), index + 1))),
    factors,
    reasons: explainRisk(current, recent),
    scenarios: buildScenarios(current, history, riskScore),
    source: "mock",
  };
}

function predictionApiUrl() {
  return (import.meta.env.VITE_PREDICTION_API_URL as string | undefined)?.replace(/\/$/, "");
}

async function predictWithApi(input: PredictionInput): Promise<PredictionResult> {
  const endpoint = predictionApiUrl();
  if (!endpoint) throw new Error("El endpoint de predicción API no está configurado.");
  const response = await fetch(`${endpoint}/predict`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...input, fecha_indice: input.fechaIndice ?? datasetLatestDate }),
  });
  if (!response.ok) throw new Error(`El servicio de predicción respondió ${response.status}.`);
  const result: unknown = await response.json();
  return validateApiPrediction(result);
}

export async function predict(input: PredictionInput, mode = getPredictionMode()) {
  return mode === "api" ? predictWithApi(input) : buildPrediction(input);
}

export function predictMock(input: PredictionInput) {
  return buildPrediction(input);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}

function isDatasetRowForPrediction(value: unknown): value is DatasetRow {
  if (!isRecord(value)) return false;
  const requiredFields = [
    "fecha_indice",
    "calidad_sueno",
    "modo_despertar",
    "estado_gastrointestinal",
    "nivel_regulacion_general_dia",
    "asistencia_establecimiento",
    "nivel_ruido_ambiente",
    "transicion_dificil",
    "hubo_sesion_profesional",
    "nivel_alerta_final_sesion",
    "eventos_mismo_dia",
  ];
  return requiredFields.every((field) => typeof value[field] === "string");
}

function validateApiPrediction(value: unknown): PredictionResult {
  if (!isRecord(value)) throw new Error("La API de predicción devolvió una respuesta inválida.");
  const hasValidFactors = Array.isArray(value.factors) && value.factors.every((factor) =>
    isRecord(factor) &&
    typeof factor.label === "string" &&
    typeof factor.value === "number" &&
    ["up", "down", "neutral"].includes(String(factor.direction)),
  );
  const hasValidScenarios = Array.isArray(value.scenarios) && value.scenarios.every((scenario) =>
    isRecord(scenario) &&
    ["title", "signs", "level", "preventiveStrategy", "regulationStrategy", "color"].every((field) => typeof scenario[field] === "string"),
  );
  const valid = typeof value.riskScore === "number" &&
    Number.isFinite(value.riskScore) &&
    typeof value.confidenceScore === "number" &&
    Number.isFinite(value.confidenceScore) &&
    isDatasetRowForPrediction(value.current) &&
    Array.isArray(value.recent) &&
    value.recent.every(isDatasetRowForPrediction) &&
    Array.isArray(value.trendScores) &&
    value.trendScores.every((score) => typeof score === "number" && Number.isFinite(score)) &&
    hasValidFactors &&
    Array.isArray(value.reasons) &&
    value.reasons.every((reason) => typeof reason === "string") &&
    hasValidScenarios;
  if (!valid) throw new Error("La API de predicción no cumple el contrato esperado.");
  const result = value as {
    riskScore: number;
    confidenceScore: number;
    current: DatasetRow;
    recent: DatasetRow[];
    trendScores: number[];
    factors: PredictionFactor[];
    reasons: string[];
    scenarios: PredictionScenario[];
  };
  return {
    ...result,
    source: "api",
  };
}